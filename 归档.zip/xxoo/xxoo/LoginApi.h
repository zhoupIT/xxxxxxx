//
//  LoginApi.h
//  xxoo
//
//  Created by 鹏 周 on 2020/5/17.
//  Copyright © 2020 render. All rights reserved.
//

#import "API.h"
#import "LoginParams.h"
NS_ASSUME_NONNULL_BEGIN
@class LoginTarget;
@interface LoginApi: API <LoginTarget *,LoginParams *>

@end

NS_ASSUME_NONNULL_END
