//
//  APIStore.m
//  AIWAYS
//
//  Created by hanlei on 2019/1/14.
//  Copyright © 2019年 wlq. All rights reserved.
//

#import "APIHeaderCache.h"
#import "APIDispose.h"

#define Notification_registerIDKey @"Always_Notification_registerIDKey"
#define Notification_tokenKey @"Notification_tokenKey"
#define TokenKey @"token"

@interface APIHeaderCache ()

/// 网络请求token
@property (nonatomic, readwrite) NSString *token;
/// 注册生成对应的远程绑定ID （极光设备ID）
@property (nonatomic, readwrite) NSString *registrationID;
/// app 版本
@property (nonatomic, readwrite) NSString *appVersion;

@end
@implementation APIHeaderCache

+ (APIHeaderCache *)share {
    static APIHeaderCache *cache;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cache = [[APIHeaderCache alloc] init];
    });
    return cache;
}

+ (void)clean {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:Notification_tokenKey];
    [defaults removeObjectForKey:TokenKey];
    [defaults removeObjectForKey:Notification_registerIDKey];
    [defaults synchronize];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}
- (void)setup {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//    NSString *tokenText = [defaults stringForKey:Notification_tokenKey];
    NSString *tokenText = [defaults stringForKey:TokenKey];
    _token = tokenText;
    
    _appVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    
    NSString *regId = [defaults stringForKey:Notification_registerIDKey];
    _registrationID = regId;
 
}

#pragma mark - 修改本地数据
+ (void)updateToken:(NSString *)token {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//    [defaults setObject:token forKey:Notification_tokenKey];
    [defaults setObject:token forKey:TokenKey];
    [defaults synchronize];
    [APIHeaderCache share].token = token;
}
+ (NSString *)getToken {
    return [APIHeaderCache share].token;;
}

+ (void)updateRegistrationID:(NSString *)registrationID {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:registrationID forKey:Notification_registerIDKey];
    [defaults synchronize];
    [APIHeaderCache share].registrationID = registrationID;
}
+ (NSString *)getRegistrationID {
    return [APIHeaderCache share].registrationID;
}
@end
