//
//  APIReinforcement.m
//  AIWAYS
//
//  Created by hanlei on 2019/4/16.
//  Copyright © 2019年 wlq. All rights reserved.
//

//#import "APIReinforcement.h"
////#import "XDSafeComm.h"
//#import "APIConfig.h"
//#import "SSKeychain.h"
//#import "NetPath.h"
//
////static NSString * const ReinforcementKey = @"_ReinforcementKey";
//static NSString * const ReinforcementURLKey = @"_ReinforcementURLKey";
//static NSString * const ReinforcementSwitchKey = @"_reinforcementSwitchKey";
//
//@interface APIReinforcement ()//<XDSafeCommDelegate>
//
//@property (nonatomic, readwrite) BOOL enableNetwork;
//@property (nullable ,nonatomic, readwrite) NSString *reinforcementURL;
//@property (nonatomic) Kle_ReinforcementHandler handler;
//
//@end
//@implementation APIReinforcement
//
//+ (APIReinforcement *)share {
//    static APIReinforcement *_reinforcement;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        _reinforcement = [APIReinforcement new];
//    });
//    return _reinforcement;
//}
//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        [self setup];
//    }
//    return self;
//}
//- (void)setup {
//    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
//    _reinforcementURL = [userDef stringForKey:ReinforcementURLKey];
//    
//    _inforceSwitch = [userDef boolForKey:ReinforcementSwitchKey];
//}
//
//- (void)reinfocement:(Kle_ReinforcementHandler)handler {
//    _handler = handler;
//    static NSString *const service = @"Aiways_service";
//    static NSString *const account = @"userId";
//    NSString *uuid = [SSKeychain passwordForService:service account:account];
//    if (nil == uuid) {
//        uuid = [[NSUUID UUID] UUIDString];
//        [SSKeychain setPassword:uuid forService:service account:account];
//    }
//    NSString *reqCertUrl = @"47.102.62.8:8443";
//    //TODO
//    NSString *homePath = NSHomeDirectory();
//    NSString *aiwaysCerPath = [homePath stringByAppendingPathComponent:@"Documents/AiwaysCer"];
////    [[XDSafeComm getInstance] configDir:aiwaysCerPath appUUID:uuid issueCertUrl:reqCertUrl];
////    [XDSafeComm getInstance].enable;
////    NSString *userId = @"userId";
////    NSString *wgIp = @"47.102.62.8";
////    //TODO
////    int wgPort = 80;
////    [XDSafeComm getInstance].delegate = self;
////    [[XDSafeComm getInstance] createSafeconnect:reqCertUrl userId:userId wgIp:wgIp wgPort:wgPort];
//}
//
//- (void)stopReinforcement {
////    [XDSafeComm getInstance].delegate = self;
////    [[XDSafeComm getInstance] destorySafeconnect];
//}
//
//#pragma mark - XDSafeCommDelegate
//- (void)onSafeCommStart:(int)state appPort:(int)port {
//    // 开启安全状态
//    NSString *host = [NSString stringWithFormat:@"http://127.0.0.1:%d",port];
//    [[NSUserDefaults standardUserDefaults] setObject:host forKey:ReinforcementURLKey];
//    _enableNetwork = true;
//    _reinforcementURL = host;
//    if (_handler == nil) { return ;}
//    _handler(host, nil);
//}
//
//- (void)onSafeCommDestory:(int)state {
//    // 关闭安全状态
//    _enableNetwork = false;
//}
//
//#pragma mark - 更新inforceSwitch
//- (void)updateInforceSwitch:(BOOL)inforce {
//    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
//    [userDef setObject:@(inforce) forKey:ReinforcementSwitchKey];
//    _inforceSwitch = inforce;
//    
//    [NetPath updateInforcementSwitch];
//}
/////// 请求是否需要加固权限。
////- (void)requestReinforcement:(void(^)(BOOL granted))handler {
////    handler(_inforceSwitch);
////}
//
//@end
