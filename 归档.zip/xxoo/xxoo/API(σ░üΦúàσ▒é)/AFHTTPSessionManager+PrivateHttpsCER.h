//
//  AFHTTPSessionManager+PrivateHttpsCER.h
//  AIWAYS
//
//  Created by hanlei on 2019/1/31.
//  Copyright © 2019年 wlq. All rights reserved.
//

#import "AFNetworking.h"

NS_ASSUME_NONNULL_BEGIN

@interface AFHTTPSessionManager (PrivateHttpsCER)

- (void)setHTTPSPrivateCER;

@end

NS_ASSUME_NONNULL_END
