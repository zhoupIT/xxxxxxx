//
//  APIStore.h
//  AIWAYS
//
//  Created by hanlei on 2019/1/14.
//  Copyright © 2019年 wlq. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/// API 需要存储的Header 必要信息
@interface APIHeaderCache : NSCache

@property (class, nonatomic, readonly) APIHeaderCache *share;
/// 需要清空当前存储对象 (在用户主动退出时，或强制登出时)
+ (void)clean;

/// 网络请求token
@property (nonatomic, readonly) NSString *token;
/// 注册生成对应的远程绑定ID （极光设备ID）
@property (nonatomic, readonly) NSString *registrationID;
/// app 版本
@property (nonatomic, readonly) NSString *appVersion;

#pragma mark - 修改本地数据 (获取本地数据)
+ (void)updateToken:(NSString *)token;
+ (nullable NSString *)getToken;

+ (void)updateRegistrationID:(NSString *)registrationID;
+ (nullable NSString *)getRegistrationID;
@end

NS_ASSUME_NONNULL_END
