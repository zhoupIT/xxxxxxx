//
//  APIConfig.h
//  AlawaysFeedBack-Example
//
//  Created by hanlei on 2019/1/4.
//  Copyright © 2019年 hanlei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "APIHeaderField.h"

NS_ASSUME_NONNULL_BEGIN

@interface APIConfig : NSObject

@property (class ,nonatomic, readonly) APIConfig *share;
/// 更新Host 地址。
+ (void)updateHost:(NSString *)host;
/// 远程主机地址
@property (nonatomic, readonly) NSURL *host;
/// 韩雷：2019-4-16 是否可以进行网络层访问 (当)
@property (nonatomic) BOOL enableNetwork;
/// 可设置的超时时间 （default: 10秒）
@property (nonatomic) NSTimeInterval timeoutInterval;

@property (nonatomic, readonly) APIHeaderField *header;

@end

NS_ASSUME_NONNULL_END
