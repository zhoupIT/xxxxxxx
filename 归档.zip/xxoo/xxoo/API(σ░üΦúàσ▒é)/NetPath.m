//
//  NetPath.m
//  HavalConnect
//
//  Created by NAVINFO on 17/7/21.
//  Copyright © 2017年 mengy. All rights reserved.
//

#import "NetPath.h"
#import "API.h"

#define NET_INDEX 0

static NSString *const netPathUrlKey = @"_netPathUrlKey";

@interface NetPath()

@property (nonatomic, readwrite) PathItem *selectPath;
@property (nonatomic, readwrite) NSInteger index;

@property (nonatomic, readonly) BOOL isInforcement;
@end

@implementation NetPath
/**
 获取单例对象
*/
+(instancetype)getInstance
{
    static NetPath *netPath;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        netPath = [[NetPath alloc]init];
    });
    return netPath;
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        
        [self _setup];
    }
    return self;
}

- (void)_setup {
    NSString *path = [[NSBundle mainBundle] pathForResource:@"NetPath" ofType:@"plist"];
    NSArray<NSDictionary *> *list = [NSArray arrayWithContentsOfFile:path];
    NSMutableArray<PathItem *> *pathArray = [NSMutableArray array];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *urlString = [userDefaults stringForKey:netPathUrlKey];
    /** 数据结构为:
     [
     {
     "name": "urlName",
     "url" : "urlString"
     }
     ]
     */
    for (int i=0; i<list.count ; i++) {
        NSDictionary *item = list[i];
        PathItem *temp = [[PathItem alloc] init];
        temp.name = [item objectForKey:@"name"];
        temp.url = [item objectForKey:@"url"];
        [pathArray addObject:temp];
        if ([urlString isEqualToString:temp.url]) {
            _index = i;
            _selectPath = temp;
        }
    }
    _pathList = pathArray;
    if (nil == _selectPath) {
        _selectPath = _pathList.firstObject;
    }

}



- (void)setSelectPath:(PathItem *)selectPath {
    _selectPath = selectPath;
    if ([_pathList containsObject:selectPath]) {
        NSInteger index = [_pathList indexOfObject:selectPath];
        _index = index;
    }else {
        _index = 0;
    }
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:selectPath.url forKey:netPathUrlKey];
}
- (NSString *)pathUrl {
    return _selectPath.url;
}

- (NSString *)pathnName {
    return _selectPath.name;
}

- (PathItem *)objectAtIndex:(NSIndexPath *)indexPath {
    return [_pathList objectAtIndex:indexPath.row];
}





+ (void)updateUrlPathItem:(PathItem *)item {
    NetPath *path = [NetPath getInstance];
    path.selectPath = item;
    
    [API launchHost:item.url];
}


@end

@implementation PathItem

@end
