//
//  CommonHeaderField.h
//  AlawaysFeedBack-Example
//
//  Created by hanlei on 2019/1/4.
//  Copyright © 2019年 hanlei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "APIHeaderCache.h"

NS_ASSUME_NONNULL_BEGIN

@interface APIHeaderField : NSObject
/// 时间戳 YYYY-MM-DD HH:MM:SS 19位
@property (nonatomic, copy) NSString *time;
/// 令牌
@property (nonatomic, copy) NSString *token;
@property (nonatomic, copy) NSString *device_type;
@property (nonatomic, copy) NSString *app_version;
/// 设备推送Id device token;
@property (nonatomic, copy) NSString *device_id;

@end

NS_ASSUME_NONNULL_END
