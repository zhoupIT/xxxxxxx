//
//  FeedBackAPIDispose.m
//  AlawaysFeedBack-Example
//
//  Created by hanlei on 2019/1/4.
//  Copyright © 2019年 hanlei. All rights reserved.
//

#import "APIDispose.h"
#import "APIStateTarget.h"

@implementation APIDispose

- (BOOL)dispose:(APIStateTarget *)result {
    BOOL disposeResult;
    // 状态码
    switch (result.status) {
//        case 0:
//            disposeResult = true;
//            break;
        case 200:
            disposeResult = true;
            break;
        case 9999: // 被登出
            disposeResult = false;
//            [[NSNotificationCenter defaultCenter] postNotificationName:AlawaysLogoutNotifi object:result];
            break;
        case 9996: // 被登出
            disposeResult = false;
//            [[NSNotificationCenter defaultCenter] postNotificationName:AlawaysLogoutNotifi object:result];
        case 2011: // 被登出   患者属于禁用状态！不能进行操作
            disposeResult = false;
//            [[NSNotificationCenter defaultCenter] postNotificationName:AlawaysLogoutNotifi object:result];
            break;
        default:
            disposeResult = false;
            break;
    }
    return disposeResult;
}

@end
