//
//  API+DeprecatedService.h
//  AIWAYS
//
//  Created by hanlei on 2019/1/30.
//  Copyright © 2019年 wlq. All rights reserved.
//

//#import "API.h"
//#import "NIBaseRequestObject.h"
//
//NS_ASSUME_NONNULL_BEGIN
///// 适配旧的网络请求。 (项目中已不进行使用，如有需要可以进行删除)
//@interface API (DeprecatedService)
//
//- (void)NI_POSTRequest:(NIBaseRequestObject *)reqeust withTarget:(Class)tempTarget withSuccess:(void (^)(Class obj))success withFailure:(void (^)(NSError *error))failure;
//
///// 返回session manager 用来设置超时时间，默认为10；
//- (void)NI_POSTRequest:(NIBaseRequestObject *)reqeust withTarget:(Class)tempTarget withFile:(nullable void(^)(id<AFMultipartFormData> formData))multipartBlock withSuccess:(void(^)(Class obj))success withFailure:(void(^)(NSError *error))failure;
//
//@end

//NS_ASSUME_NONNULL_END
