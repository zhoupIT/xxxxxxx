//
//  APIError.m
//  AIWAYS
//
//  Created by hanlei on 2019/1/21.
//  Copyright © 2019年 wlq. All rights reserved.
//

#import "APIError.h"
#import "APIStateTarget.h"

@interface APIError ()
@property (nonatomic) APIStateTarget *result;
@end

@implementation APIError

+ (instancetype)errorWithResult:(APIStateTarget *)result {
    APIError *error;
    if (result.message) {
        error = [APIError errorWithDomain:NSCocoaErrorDomain code:result.status userInfo:@{NSLocalizedDescriptionKey: result.message}];
    }
    else
    {
        error = [APIError errorWithDomain:NSCocoaErrorDomain code:result.status userInfo:@{NSLocalizedDescriptionKey: @"网络请求失败"}];
    }
    error.result = result;
    return error;
}
+ (instancetype)errorWithNSError:(NSError *)error {
    NSInteger transCode = error.code;
    NSString *transMsg = @"";
    switch (error.code) {
        case -1009:
            transCode = -3001;
            transMsg = @"网络连接失败";
            break;
        case -1001:
            transCode = -3002;
            transMsg = @"网络连接失败";
            break;
        case -1011:
            transCode = 404;
            transMsg = @"无法连接到服务器";
            break;
        case 404:
            transCode = 404;
            transMsg = @"无法连接到服务器";
            break;
        default:
            transCode = error.code;
            transMsg = @"请求失败";
            break;
    }
    APIError *apiError = [APIError errorWithDomain:error.domain code:transCode userInfo:@{NSLocalizedDescriptionKey: transMsg}];
    return apiError;
}

@end
