//
//  FeedBackAPIResult.m
//  AlawaysFeedBack-Example
//
//  Created by hanlei on 2019/1/4.
//  Copyright © 2019年 hanlei. All rights reserved.
//

#import "APIStateTarget.h"

@implementation APIStateTarget

+ (instancetype)resultWithFormatError {
    APIStateTarget *result = [[APIStateTarget alloc] initWithFormatError];
    return result;
}

- (instancetype)initWithFormatError {
    self = [super init];
    if (self) {
        _status = -4401;
        _message = @"数据格式错误";
    }
    return self;
}

@end
