//
//  APIReinforcement.h
//  AIWAYS
//
//  Created by hanlei on 2019/4/16.
//  Copyright © 2019年 wlq. All rights reserved.
//

//#import <Foundation/Foundation.h>
//
//typedef void(^Kle_ReinforcementHandler)(NSString *host, NSError *error);
//NS_ASSUME_NONNULL_BEGIN
//
///// API 加固
//@interface APIReinforcement : NSObject
//
//@property (class, nonatomic, readonly) APIReinforcement *share;
///// 加固开关状态
//@property (nonatomic, readonly) BOOL inforceSwitch;
//
///// 在加固状态下是否可以发送网络请求。
////@property (nonatomic, readonly) BOOL enableNetwork;
//
//@property (nullable ,nonatomic, readonly) NSString *reinforcementURL;
///// 加固 -
//- (void)reinfocement:(Kle_ReinforcementHandler)handler;
//
///// 取消加固
//- (void)stopReinforcement;
///// 更新加固 开关。 （后门切换URL可调用）
//- (void)updateInforceSwitch:(BOOL)inforce;
//
//@end
//
//NS_ASSUME_NONNULL_END
