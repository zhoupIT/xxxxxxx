//
//  APIConfig.m
//  AlawaysFeedBack-Example
//
//  Created by hanlei on 2019/1/4.
//  Copyright © 2019年 hanlei. All rights reserved.
//

#import "APIConfig.h"

#define HostKey @"Always_HostKey"

@interface APIConfig ()

@property (nonatomic, readwrite) NSURL *host;

@end

@implementation APIConfig

+ (APIConfig *)share {
    static APIConfig *config;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        config = [[APIConfig alloc] init];
    });
    return config;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    _timeoutInterval = 10;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    _host = [defaults URLForKey:HostKey];
}

- (APIHeaderField *)header {
    return [[APIHeaderField alloc] init];
}
#pragma mark - 更新当前Host
+ (void)updateHost:(NSString *)host {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *encodingHost = [host stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
    NSURL *hostURL = [NSURL URLWithString:encodingHost];
    [defaults setURL:hostURL forKey:HostKey];
    
    [APIConfig share].host = hostURL;
}

@end
