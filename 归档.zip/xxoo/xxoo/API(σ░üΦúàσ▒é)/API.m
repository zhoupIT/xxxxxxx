//
//  AlBaseRequest.m
//  AlawaysFeedBack-Example
//
//  Created by hanlei on 2019/1/4.
//  Copyright © 2019年 hanlei. All rights reserved.
//

#import "API.h"
#import "AFHTTPSessionManager+PrivateHttpsCER.h"
#import "AFHTTPSessionManager+HttpContentType.h"

@interface API ()

@property (nonatomic) Class tempTarget;

@end

@implementation API

+ (void)launchHost:(NSString *)host {
    [APIConfig updateHost:host];
}

- (instancetype)initWithParams:(NSObject *)params {
    self = [super init];
    if (self) {
        _params = params;
        [self setup];
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    _dispose = [[APIDispose alloc] init];
    _config = [[APIConfig alloc] init];
}

- (void)GETRequestWithSuccess:(void (^)(Class  _Nonnull __unsafe_unretained))success withFailure:(void (^)(NSError * _Nonnull))failure {
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSDictionary *headers = [_config.header yy_modelToJSONObject];
    configuration.HTTPAdditionalHeaders = headers;
    NSURL *host = _config.host;
    _manager = [[AFHTTPSessionManager alloc] initWithBaseURL:host sessionConfiguration:configuration];
    [_manager setHTTPSPrivateCER];
    [_manager setHttpContentType];
    NSString *requestComponent = self.component;
    NSString *urlString = [NSURL URLWithString:self.component relativeToURL:host].absoluteString;
    
    NSDictionary *params = [_params yy_modelToJSONObject];
    
    _manager.requestSerializer = [AFJSONRequestSerializer serializer];
    _manager.requestSerializer.timeoutInterval = _config.timeoutInterval;
    
    NSLog(@"日志——请求地址:%@\n header:%@\n参数：%@",urlString,headers,params);
    [self GETRequest:requestComponent parameters:params withSuccess:success withFailure:failure];
}

- (void)GETRequest:(NSString *)URLString parameters:(NSDictionary *)params withSuccess:(void (^)(Class  _Nonnull __unsafe_unretained))success withFailure:(void (^)(NSError * _Nonnull))failure {
    [_manager GET:URLString parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"🕸️ 请求%@",task.originalRequest.URL.absoluteString);
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            NSData *data = [NSJSONSerialization dataWithJSONObject:responseObject options:(NSJSONWritingPrettyPrinted) error:nil];
            NSLog(@"🕸️ 返回:%@",[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
        }
        APIStateTarget *result = [APIStateTarget yy_modelWithJSON:responseObject];
        // 检测当前结果 是否正常
        if ([self.dispose dispose:result]) { // 状态码正常
            id target = [self.target yy_modelWithJSON:responseObject];
            if (target) {
                success(target);
            }else {
                APIStateTarget *formatResult = [APIStateTarget resultWithFormatError];
                NSError *error = [APIError errorWithResult:formatResult];;
                failure(error);
            }
        }else {
            NSError *error = [APIError errorWithResult:result];
            failure(error);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"网络请求失败:%@",error.description);
        NSError *err = [APIError errorWithNSError:error];
        failure(err);
    }];
}


- (void)POSTRequestWithSuccess:(void (^)(Class  _Nonnull __unsafe_unretained))success withFailure:(void (^)(NSError * _Nonnull))failure {
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSDictionary *headers = [_config.header yy_modelToJSONObject];
    configuration.HTTPAdditionalHeaders = headers;
    NSURL *host = _config.host;
    _manager = [[AFHTTPSessionManager alloc] initWithBaseURL:host sessionConfiguration:configuration];
    [_manager setHTTPSPrivateCER];
    [_manager setHttpContentType];
    NSString *requestComponent = self.component;
    NSString *urlString = [NSURL URLWithString:self.component relativeToURL:host].absoluteString;
    
    NSDictionary *params = [_params yy_modelToJSONObject];
    
    _manager.requestSerializer = [AFJSONRequestSerializer serializer];
    _manager.requestSerializer.timeoutInterval = _config.timeoutInterval;
    NSLog(@"日志——请求地址:%@\n header:%@\n参数：%@",urlString,headers,params);
    [self POSTRequest:requestComponent parameters:params withSuccess:success withFailure:failure];
}
- (void)POSTRequest:(NSString *)URLString parameters:(NSDictionary *)params withSuccess:(void (^)(Class  _Nonnull __unsafe_unretained))success withFailure:(void (^)(NSError * _Nonnull))failure {
    [_manager POST:URLString parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"🕸️ 请求%@",task.originalRequest.URL.absoluteString);
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            NSData *data = [NSJSONSerialization dataWithJSONObject:responseObject options:(NSJSONWritingPrettyPrinted) error:nil];
            NSLog(@"🕸️ 返回:%@",[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
        }
        APIStateTarget *result = [APIStateTarget yy_modelWithJSON:responseObject];
        // 检测当前结果 是否正常
        if ([self.dispose dispose:result]) { // 状态码正常
            id target = [self.target yy_modelWithJSON:responseObject];
            if (target) {
                success(target);
            }else {
                APIStateTarget *formatResult = [APIStateTarget resultWithFormatError];
                NSError *error = [APIError errorWithResult:formatResult];
                failure(error);
            }
        }else {
            NSError *error = [APIError errorWithResult:result];
            failure(error);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"网络请求失败:%@",error.description);
        NSError *err = [APIError errorWithNSError:error];
        failure(err);
    }];
}

- (void)POSTRequestWithFile:(nullable void (^)(id<AFMultipartFormData> _Nonnull))multipartBlock withSuccess:(void (^)(Class  _Nonnull __unsafe_unretained))success withFailure:(void (^)(NSError * _Nonnull))failure {
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSDictionary *headers = [_config.header yy_modelToJSONObject];
    configuration.HTTPAdditionalHeaders = headers;
    
    NSURL *host = _config.host;
    _manager = [[AFHTTPSessionManager alloc] initWithBaseURL:host sessionConfiguration:configuration];
    [_manager setHTTPSPrivateCER];
    [_manager setHttpContentType];
    NSString *requestComponent = self.component;
    NSString *urlString = [NSURL URLWithString:self.component relativeToURL:host].absoluteString;
    
    NSDictionary *params = [_params yy_modelToJSONObject];
    
    _manager.requestSerializer = [AFJSONRequestSerializer serializer];
    _manager.requestSerializer.timeoutInterval = _config.timeoutInterval;
    
    NSLog(@"日志——请求地址:%@\n header:%@\n参数：%@",urlString,headers,params);
    [self POSTFileRequest:requestComponent parameters:params file:multipartBlock withSuccess:success withFailure:failure];
}

- (void)POSTFileRequest:(NSString *)URLString parameters:(NSDictionary *)params file:(nullable void (^)(id<AFMultipartFormData> _Nonnull))multipartBlock withSuccess:(void (^)(Class  _Nonnull __unsafe_unretained))success withFailure:(void (^)(NSError * _Nonnull))failure {
    [_manager POST:URLString parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        if (multipartBlock) {
            multipartBlock(formData);
            NSLog(@"o拼接-formData：%@",formData);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"🕸️ 请求%@",task.originalRequest.URL.absoluteString);
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            NSData *data = [NSJSONSerialization dataWithJSONObject:responseObject options:(NSJSONWritingPrettyPrinted) error:nil];
            NSLog(@"🕸️ 返回:%@",[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
        }
        APIStateTarget *result = [APIStateTarget yy_modelWithJSON:responseObject];
        // 检测当前结果 是否正常
        if ([self.dispose dispose:result]) { // 状态码正常
            id target = [self.target yy_modelWithJSON:responseObject];
            if (target) {
                success(target);
            }else {
                APIStateTarget *formatResult = [APIStateTarget resultWithFormatError];
                NSError *error = [APIError errorWithResult:formatResult];
                failure(error);
            }
        }else {
            NSError *error = [APIError errorWithResult:result];
            failure(error);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"网络请求失败:%@",error.description);
        NSError *err = [APIError errorWithNSError:error];
        failure(err);
    }];
}

#pragma mark 识别卡路里上传图片
- (void)POSTRequestWithFile:(nullable void (^)(id<AFMultipartFormData> _Nonnull))multipartBlock withSuccess:(void (^)(Class  _Nonnull __unsafe_unretained))success withFailure:(void (^)(NSError * _Nonnull))failure host:(NSString *)host
{
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSDictionary *headers = [_config.header yy_modelToJSONObject];
    configuration.HTTPAdditionalHeaders = headers;
    
    NSString *encodingHost = [host stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
    NSURL *hostURL = [NSURL URLWithString:encodingHost];
    
    _manager = [[AFHTTPSessionManager alloc] initWithBaseURL:hostURL sessionConfiguration:configuration];
    [_manager setHTTPSPrivateCER];
    [_manager setHttpContentType];
    NSString *requestComponent = self.component;
    NSString *urlString = [NSURL URLWithString:self.component relativeToURL:hostURL].absoluteString;
    
    NSDictionary *params = [_params yy_modelToJSONObject];
    
    _manager.requestSerializer = [AFJSONRequestSerializer serializer];
    _manager.requestSerializer.timeoutInterval = _config.timeoutInterval;
    
    NSLog(@"日志——请求地址:%@\n header:%@\n参数：%@",urlString,headers,params);
    [self POSTFileRequest:requestComponent parameters:params file:multipartBlock withSuccess:success withFailure:failure];
}


#pragma mark - 添加旧版本target适配
- (void)config_TempTarget:(Class)tempTarget {
    _tempTarget = tempTarget;
}
- (Class)target {
    return _tempTarget;
}

//- (NSString *)component {
//    return @"/login/v1"
//}
//
//- (T)target {
//    return [LoginTarget Class];
//}
@end
