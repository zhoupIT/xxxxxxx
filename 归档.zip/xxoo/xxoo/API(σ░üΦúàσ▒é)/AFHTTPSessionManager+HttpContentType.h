//
//  AFHTTPSessionManager+HttpContentType.h
//  AIWAYS
//
//  Created by Marx on 2019/4/19.
//  Copyright © 2019年 wlq. All rights reserved.
//

#import "AFNetworking.h"

NS_ASSUME_NONNULL_BEGIN

@interface AFHTTPSessionManager (HttpContentType)
- (void)setHttpContentType;
@end

NS_ASSUME_NONNULL_END
