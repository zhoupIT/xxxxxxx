//
//  AlBaseRequest.h
//  AlawaysFeedBack-Example
//
//  Created by hanlei on 2019/1/4.
//  Copyright © 2019年 hanlei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "YYModel.h"

#import "APIDispose.h"
#import "APIConfig.h"
#import "APIStateTarget.h"
#import "APIHeaderField.h"
#import "APIError.h"
#import "APIReinforcement.h"

NS_ASSUME_NONNULL_BEGIN
/** 网络请求封装 -- （需要在使用前 初始化启动。）
       / |  url      |  params     |   header         | -> (target || error)
  API -  |  URL      |  P          | HeaderField      | 返回 结果
       \ |  host+URL |  Struct+yy  | HeaderField + yy | 自定义结构体 或 错误
 T: target 返回正确结果的结构体（oc轻量级泛型，需要子类显式声明该对象class类型）
 P: params 输入参数结构体 （因为需要写入操作，所以不需要显式的声明该对象）
 config: 包含header输入参数+host信息+超时时间 \
 dispose: 包含处理方法状态码方法              /
 config&dispose: 也可以通过遵循协议处理，暂时未进行开发协议化处理。
 */
@interface API<T: Class, P: NSObject *> : NSObject
/// 内部使用， 外部请不要调用
@property (nonatomic) AFHTTPSessionManager *manager;

- (instancetype)initWithParams:(P)params;

/// 网络层启动 Host 值
+ (void)launchHost:(NSString *)host;

/// 接口component (子类复写该属性)
@property (nonatomic, readonly) NSString *component;
/// target : 轻量级泛型，需要子类显示声明类型！ description So the entire 'lightweight generics' feature is based on a 'type erasure model'. Which means that the compiler has all of this rich static type information but it erases that information when generating code.  (尽量在子类中实现唯一可读属性。)
@property (nonatomic, readonly) T target;
@property (nonatomic, nullable) P params;

/// 处理返回数据 & 判断code字段返回值 - default: instance value
@property (nonatomic) id<APIDisposeDelegate> dispose;

/// 配置项  request info -- default: instance value; (host & header)
@property (nonatomic) APIConfig *config;

- (void)GETRequestWithSuccess:(void(^)(T obj))success withFailure:(void(^)(NSError *error))failure;

- (void)POSTRequestWithSuccess:(void(^)(T obj))success withFailure:(void(^)(NSError *error))failure;

///
- (void)POSTRequestWithFile:(nullable void(^)(id<AFMultipartFormData> formData))multipartBlock withSuccess:(void(^)(T obj))success withFailure:(void(^)(NSError *error))failure;


//上传图片识别卡路里baseUrl不同，单独抽取一个方法
- (void)POSTRequestWithFile:(nullable void(^)(id<AFMultipartFormData> formData))multipartBlock withSuccess:(void(^)(T obj))success withFailure:(void(^)(NSError *error))failure host:(NSString *)host;

#pragma mark - 以下为内部调用使用
//- (void)POSTRequest:(NSString *)URLString parameters:(NSDictionary *)params withSuccess:(void(^)(T obj))success withFailure:(void(^)(NSError *error))failure;

//- (void)POSTFileRequest:(NSString *)URLString parameters:(NSDictionary *)params file:(nullable void(^)(id<AFMultipartFormData> formData))multipartBlock withSuccess:(void(^)(T obj))success withFailure:(void(^)(NSError *error))failure;

#pragma mark - 添加旧版本target适配
//- (void)config_TempTarget:(Class)tempTarget;

@end

NS_ASSUME_NONNULL_END
