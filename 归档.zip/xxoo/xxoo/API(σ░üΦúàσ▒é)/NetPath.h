//
//  NetPath.h
//  HavalConnect
//
//  Created by NAVINFO on 17/7/21.
//  Copyright © 2017年 mengy. All rights reserved.
//

#import <Foundation/Foundation.h>
@class PathItem;


//环境选择key
#define USERDEFAULTSKEY_NET_PATH_INDEX        @"userDefultsNetPathIndexKey"

@interface NetPath : NSObject
#pragma mark - 网络URL列表采用 plist 文件存储
@property (nonatomic) NSArray<PathItem *> *pathList;

+(instancetype)getInstance;

/// 更新当前选中的 URL
+ (void)updateUrlPathItem:(PathItem *)item;

/// 获取当前的URL 如果未选择过，那么selectPath 可用列表第一个
@property (nonatomic, readonly) PathItem *selectPath;
/// 当前选中的pathURL
@property (nonatomic, readonly) NSString *pathUrl;
@property (nonatomic, readonly) NSString *pathnName;
/// 如果没有选中的值 未匹配到有效URL路径时 index = 0
@property (nonatomic, readonly) NSInteger index;


- (PathItem *)objectAtIndex:(NSIndexPath *)indexPath;

@end

@interface PathItem : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) NSString *url;

@end
