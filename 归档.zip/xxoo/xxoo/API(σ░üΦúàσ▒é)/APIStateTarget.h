//
//  FeedBackAPIResult.h
//  AlawaysFeedBack-Example
//
//  Created by hanlei on 2019/1/4.
//  Copyright © 2019年 hanlei. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface APIStateTarget : NSObject

@property (nonatomic) NSInteger status;
@property (nonatomic) NSString *message;

+ (instancetype)resultWithFormatError;
- (instancetype)initWithFormatError;

@end

NS_ASSUME_NONNULL_END
