//
//  AFHTTPSessionManager+HttpContentType.m
//  AIWAYS
//
//  Created by Marx on 2019/4/19.
//  Copyright © 2019年 wlq. All rights reserved.
//

#import "AFHTTPSessionManager+HttpContentType.h"

@implementation AFHTTPSessionManager (HttpContentType)

- (void)setHttpContentType {
    self.responseSerializer.acceptableContentTypes = [NSSet
                                                      setWithObjects:@"application/json",@"text/json",
                                                      @"text/plain",
                                                      nil];
}

@end
