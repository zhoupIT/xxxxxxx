//
//  APIError.h
//  AIWAYS
//
//  Created by hanlei on 2019/1/21.
//  Copyright © 2019年 wlq. All rights reserved.
//

#import <Foundation/Foundation.h>
@class APIStateTarget;
NS_ASSUME_NONNULL_BEGIN

@interface APIError : NSError

+ (instancetype)errorWithResult:(APIStateTarget *)result;

+ (instancetype)errorWithNSError:(NSError *)error;

@end

NS_ASSUME_NONNULL_END
