//
//  AFHTTPSessionManager+PrivateHttpsCER.m
//  AIWAYS
//
//  Created by hanlei on 2019/1/31.
//  Copyright © 2019年 wlq. All rights reserved.
//

#import "AFHTTPSessionManager+PrivateHttpsCER.h"
//证书名称定义app
#define SSL_CER @"SSL_CER"

@implementation AFHTTPSessionManager (PrivateHttpsCER)

- (void)setHTTPSPrivateCER {
    // AFSSLPinningModeCertificate 使用证书验证模式
    //AFSSLPinningModeNone: 代表客户端无条件地信任服务器端返回的证书。
    //AFSSLPinningModePublicKey: 代表客户端会将服务器端返回的证书与本地保存的证书中，PublicKey的部分进行校验；如果正确，才继续进行。
    //AFSSLPinningModeCertificate: 代表客户端会将服务器端返回的证书和本地保存的证书中的所有内容，包括PublicKey和证书部分，全部进行校验；如果正确，才继续进行。
//    BOOL isVerifySSL = [NetPath getInstance].isPrivateHttps;
    BOOL isVerifySSL = [self.baseURL.absoluteString containsString:@"https://"];
    
    //isVerifySSL 是否需要验证SSL
    if (isVerifySSL) {
        AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
        securityPolicy.allowInvalidCertificates = true;
        securityPolicy.validatesDomainName = false;
        //先导入证书
        NSString *cerStr = [[NSUserDefaults standardUserDefaults] objectForKey:SSL_CER];
        if (cerStr) {
            NSData *dataFromBase64String = [cerStr dataUsingEncoding:0];
            securityPolicy.pinnedCertificates = [[NSSet alloc] initWithObjects:dataFromBase64String, nil];
        }
        [self setSecurityPolicy:securityPolicy];
//    }else{
//        securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
//        // allowInvalidCertificates 是否允许无效证书（也就是自建的证书），默认为NO
//        // 如果是需要验证自建证书，需要设置为YES
//        //    allowInvalidCertificates 定义了客户端是否信任非法证书。一般来说，每个版本的iOS设备中，都会包含一些既有的CA根证书。如果接收到的证书是iOS信任的CA根证书签名的，那么则为合法证书；否则则为“非法”证书。
//        securityPolicy.allowInvalidCertificates = YES;
//
//        //validatesDomainName 是否需要验证域名，默认为YES；
//        //如置为NO，建议自己添加对应域名的校验逻辑。
//        securityPolicy.validatesDomainName = NO;
//
    }
}

@end
