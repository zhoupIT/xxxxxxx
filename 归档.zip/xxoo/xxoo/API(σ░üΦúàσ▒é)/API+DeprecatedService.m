//
//  API+DeprecatedService.m
//  AIWAYS
//
//  Created by hanlei on 2019/1/30.
//  Copyright © 2019年 wlq. All rights reserved.
//

//#import "API+DeprecatedService.h"
//#import "AFHTTPSessionManager+PrivateHttpsCER.h"
//
//@implementation API (DeprecatedService)
//
///// 适配老的网络请求。
//- (void)NI_POSTRequest:(NIBaseRequestObject *)reqeust withTarget:(Class)tempTarget withSuccess:(void (^)(Class  _Nonnull __unsafe_unretained))success withFailure:(void (^)(NSError * _Nonnull))failure {
////    [self config_TempTarget:tempTarget];
//    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
//
//    NSDictionary *headers = [self.config.header yy_modelToJSONObject];
//    configuration.HTTPAdditionalHeaders = headers;
//
//    NSURL *requestURL = [NSURL URLWithString:reqeust.urlString];
//
//    self.manager = [[AFHTTPSessionManager alloc] initWithBaseURL:nil sessionConfiguration:configuration];
//    [self.manager setHTTPSPrivateCER];
//    NSString *urlString = [requestURL.absoluteString stringByAppendingString:reqeust.interfaceName];
//    NSDictionary *params = [reqeust getDicFromObject];
//
//    self.manager.requestSerializer = [AFJSONRequestSerializer serializer];
//    self.manager.requestSerializer.timeoutInterval = self.config.timeoutInterval;
//
//    NSLog(@"日志——请求地址:%@\n header:%@\n参数：%@",urlString,headers,params);
////    [self POSTRequest:urlString parameters:params withSuccess:success withFailure:failure];
//}
//
//- (void)NI_POSTRequest:(NIBaseRequestObject *)reqeust withTarget:(Class)tempTarget withFile:(void (^)(id<AFMultipartFormData> _Nonnull))multipartBlock withSuccess:(void (^)(Class  _Nonnull __unsafe_unretained))success withFailure:(void (^)(NSError * _Nonnull))failure {
////    [self config_TempTarget:tempTarget];
//    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
//
//    NSDictionary *headers = [self.config.header yy_modelToJSONObject];
//    configuration.HTTPAdditionalHeaders = headers;
//
//    NSURL *requestURL = [NSURL URLWithString:reqeust.urlString];
//
//    self.manager = [[AFHTTPSessionManager alloc] initWithBaseURL:nil sessionConfiguration:configuration];
//    [self.manager setHTTPSPrivateCER];
//    NSString *urlString = [requestURL.absoluteString stringByAppendingString:reqeust.interfaceName];
//    NSDictionary *params = [reqeust getDicFromObject];
//
//    self.manager.requestSerializer = [AFJSONRequestSerializer serializer];
//    self.manager.requestSerializer.timeoutInterval = self.config.timeoutInterval;
//
////    [self POSTFileRequest:urlString parameters:params file:multipartBlock withSuccess:success withFailure:failure];
//}

//@end
