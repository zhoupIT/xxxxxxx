//
//  CommonHeaderField.m
//  AlawaysFeedBack-Example
//
//  Created by hanlei on 2019/1/4.
//  Copyright © 2019年 hanlei. All rights reserved.
//

#import "APIHeaderField.h"
//#import "WeCloudManager.h"
//#import "AppContext.h"
//#import "NSDate+TimeStamp.h"


@implementation APIHeaderField

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}
- (void)setup {
//    _time = [[NSDate date] timeStamp_headerFormat];
    APIHeaderCache *store = [[APIHeaderCache alloc] init];
    _device_type = @"iOS";
    _app_version = store.appVersion;
    _device_id = store.registrationID;
//    if ([AppContext getInstance].isLogin) {
//        _token = store.token;
//    }
    _token = store.token;
}

@end
