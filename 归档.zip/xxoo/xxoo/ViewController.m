//
//  ViewController.m
//  xxoo
//
//  Created by 鹏 周 on 2020/5/17.
//  Copyright © 2020 render. All rights reserved.
//

#import "ViewController.h"
#import "LoginApi.h"
#import "LoginParams.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    LoginParams *param = [[LoginParams alloc] init];
    param.account = @"账号1";
    param.password = @"123456";
    LoginApi *api = [[LoginApi alloc] initWithParams:param];
    [api POSTRequestWithSuccess:^(LoginTarget * _Nonnull __unsafe_unretained obj) {
        
    } withFailure:^(NSError * _Nonnull error) {
        
    }];
}


@end
