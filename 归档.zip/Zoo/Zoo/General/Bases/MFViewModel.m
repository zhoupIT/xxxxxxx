//
//  MFViewModel.m
//  Pods
//
//  Created by tanfameng on 2017/6/20.
//
//

#import "MFViewModel.h"

@implementation MFViewModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self bindModel];
    }
    
    return self;
}

- (void)bindModel
{
    
}

@end
