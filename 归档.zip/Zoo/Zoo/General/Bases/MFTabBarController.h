//
//  MFTabBarController.h
//  Pods
//
//  Created by tanfameng on 2017/6/20.
//
//

#import <UIKit/UIKit.h>

@interface MFTabBarController : UITabBarController

@end
