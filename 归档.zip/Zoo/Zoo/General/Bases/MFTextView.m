//
//  MFTextView.m
//  Pods
//
//  Created by 方子扬 on 2017/6/27.
//
//

#import "MFTextView.h"

@implementation MFTextView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
