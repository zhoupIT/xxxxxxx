//
//  MFBusiness.h
//  Pods
//
//  Created by 方子扬 on 2017/6/20.
//
//

#import "MFObject.h"

/**
 业务基类
 */
@interface MFBusiness : MFObject

@end
