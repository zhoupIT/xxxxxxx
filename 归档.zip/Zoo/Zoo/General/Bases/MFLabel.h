//
//  MFLabel.h
//  Pods
//
//  Created by 方子扬 on 2017/6/27.
//
//

#import <UIKit/UIKit.h>

@interface MFLabel : UILabel

@end
