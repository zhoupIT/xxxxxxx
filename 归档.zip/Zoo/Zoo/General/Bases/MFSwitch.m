//
//  MFSwitch.m
//  Pods
//
//  Created by tanfameng on 2017/6/20.
//
//

#import "MFSwitch.h"

@implementation MFSwitch

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
