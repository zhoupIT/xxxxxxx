//
//  MFTabBarController.m
//  Pods
//
//  Created by tanfameng on 2017/6/20.
//
//

#import "MFTabBarController.h"

@interface MFTabBarController ()

@end

@implementation MFTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
