//
//  MFObject.h
//  Pods
//
//  Created by 方子扬 on 2017/6/20.
//
//

#import <UIKit/UIKit.h>

/**
 Object基类
 */
@interface MFObject : NSObject

@end
