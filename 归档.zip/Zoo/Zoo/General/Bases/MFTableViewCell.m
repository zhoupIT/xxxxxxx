//
//  MFTableViewCell.m
//  Pods
//
//  Created by 方子扬 on 2017/6/27.
//
//

#import "MFTableViewCell.h"

@implementation MFTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
