//
//  MWChartBaseView.m
//  Mica_MiniBI
//
//  Created by FMTAN on 16/3/9.
//  Copyright © 2016年 maywide. All rights reserved.
//

#import "MWChartBaseView.h"
#import "MFChartModel.h"

@implementation MWChartBaseView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)loadChartView
{

}

- (void)reLoadWithData:(MFChartModel *)chartModel
{
    
}

@end
