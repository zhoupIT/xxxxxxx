//
//  MainTabbarViewController.h
//  Zoo
//
//  Created by tanfameng on 2018/2/9.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFTabBarController.h"

@interface MainTabbarViewController : MFTabBarController

@end
