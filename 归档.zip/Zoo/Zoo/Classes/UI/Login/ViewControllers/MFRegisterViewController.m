//
//  MFRegisterViewController.m
//  Zoo
//
//  Created by tanfameng on 2018/2/28.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFRegisterViewController.h"
#import "MFKitBases.h"
#import "MFKitMarcro.h"
#import "UIImage+MFAdd.h"
#import "UIColor+MFAdd.h"
#import "WRNavigationBar.h"
#import <Masonry/Masonry.h>
#import <ReactiveCocoa/ReactiveCocoa.h>
#import <BlocksKit/UIControl+BlocksKit.h>
#import "MFRegisterViewModel.h"
#import <SVProgressHUD/SVProgressHUD.h>
#import "ZYDoFinishViewController.h"
#import <YPNavigationBarTransition/YPNavigationBarTransition.h>
@interface MFRegisterViewController ()<YPNavigationBarConfigureStyle>

@property (nonatomic, strong) MFRegisterViewModel *viewModel;

@property (nonatomic, strong) MFTextField *nameTextField;

@property (nonatomic, strong) MFTextField *passTextField;

@property (nonatomic, strong) MFButton *registerButton;


@property (nonatomic, strong) MFView *ownView;

@property (nonatomic, strong) MFButton *findBtn;

@end

@implementation MFRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"注册账号";
    
}

- (void)back {
    [self.navigationController popViewControllerAnimated:YES];
}

//-(void)configNavigationBar
//{
//    [super configNavigationBar];
//}

-(void)configView
{
    [super configView];
    self.view.backgroundColor = [UIColor whiteColor];
    //账号
    MFImageView *nameView = [MFImageView new];
    nameView.userInteractionEnabled = YES;
    nameView.image = [UIImage imageNamed:@"inputBgImage"];
    [self.view addSubview:nameView];
    _nameTextField = [[MFTextField alloc] init];
    _nameTextField.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
    _nameTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    NSString *namePlace = @"手机/邮箱";
    NSMutableAttributedString *namePlaceholder = [[NSMutableAttributedString alloc] initWithString:namePlace];
    [namePlaceholder addAttribute:NSForegroundColorAttributeName
                            value:[MFColor mf_fontGrayStyleColor]
                            range:NSMakeRange(0, namePlace.length)];
    [namePlaceholder addAttribute:NSFontAttributeName
                            value:[UIFont fontWithName:@"PingFangSC-Medium" size:13]
                            range:NSMakeRange(0, namePlace.length)];
    _nameTextField.attributedPlaceholder = namePlaceholder;
    //    if (userName) {
    //        _nameTextField.text = userName;
    //    }
    [nameView addSubview:_nameTextField];
    
    //密码
    MFImageView *passView = [MFImageView new];
    passView.userInteractionEnabled = YES;
    passView.image = [UIImage imageNamed:@"inputBgImage"];
    [self.view addSubview:passView];
    _passTextField = [[MFTextField alloc] init];
    _passTextField.secureTextEntry = YES;
    _passTextField.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
    _passTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //    NSString *passPlace = @"输入验证码";
    NSString *passPlace = @"验证码";
    NSMutableAttributedString *passPlaceholder = [[NSMutableAttributedString alloc] initWithString:passPlace];
    [passPlaceholder addAttribute:NSForegroundColorAttributeName
                            value:[MFColor mf_fontGrayStyleColor]
                            range:NSMakeRange(0, passPlace.length)];
    [passPlaceholder addAttribute:NSFontAttributeName
                            value:[UIFont fontWithName:@"PingFangSC-Medium" size:13]
                            range:NSMakeRange(0, passPlace.length)];
    _passTextField.attributedPlaceholder = passPlaceholder;
    //    if (passWord) {
    //        _passTextField.text = passWord;
    //    }
    [passView addSubview:_passTextField];
    
    //获取验证码
    MFButton *findBtn = [MFButton buttonWithType:UIButtonTypeSystem];
    _findBtn = findBtn;
//    findBtn.layer.cornerRadius = 13;
//    findBtn.layer.masksToBounds = YES;
//    UIImage *getCodeImage = [UIImage imageWithColor:[MFColor mf_colorWithHexString:@"00DAAA"] size:CGSizeMake(100, 30)];
//    [findBtn setBackgroundImage:getCodeImage forState:UIControlStateNormal];
    [findBtn setTitleColor:[MFColor mf_colorWithHexString:@"00CA9D"] forState:UIControlStateNormal];
    [findBtn setTitle:@"获 取" forState:UIControlStateNormal];
    findBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
    [passView addSubview:findBtn];
    
    
    //注册按钮
    MFButton *butDone = [MFButton buttonWithType:UIButtonTypeCustom];
    [butDone setBackgroundImage:[UIImage imageNamed:@"loginBtnImage"] forState:UIControlStateNormal];
    butDone.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
    [butDone setTitle:@"注 册" forState:UIControlStateNormal];
    _registerButton = butDone;
    [self.view addSubview:butDone];
    
    //已有账号view
    MFView *ownView = [[MFView alloc] init];
    _ownView = ownView;
    [self.view addSubview:ownView];
    
    MFLabel *ownLabel = [[MFLabel alloc] init];
    [_ownView addSubview:ownLabel];
    ownLabel.text = @"已有账号";
    ownLabel.tintColor = [MFColor mf_colorWithHexString:@"00CA9D"];
    ownLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
    
    
    
    MFButton *ownBtn = [MFButton buttonWithType:UIButtonTypeCustom];
    [_ownView addSubview:ownBtn];
//    ownBtn.tintColor = [MFColor mf_colorWithHexString:@"00CA9D"];
    [ownBtn setTitleColor:[MFColor mf_colorWithHexString:@"00CA9D"] forState:UIControlStateNormal];
    [ownBtn setTitle:@"登录" forState:UIControlStateNormal];
    ownBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
//    ownBtn.backgroundColor = [UIColor grayColor];
    
    [ownBtn bk_addEventHandler:^(id sender) {
//        @strongify(self);
//        [self.navigationController popViewControllerAnimated:YES];
        ZYDoFinishViewController *vc = [[ZYDoFinishViewController alloc] init];
        vc.type = @"注册";
        [self.navigationController pushViewController:vc animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    
    [nameView mas_makeConstraints:^(MASConstraintMaker *make) {
//        @strongify(self);
//        make.top.equalTo(introLabel.mas_bottom).offset(30);
        make.top.equalTo(self.view).offset(kNavigationHeight+64);
        make.left.equalTo(self.view).offset(46);
        make.right.equalTo(self.view).offset(-46);
        make.height.mas_equalTo(44);
    }];
    [_nameTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.bottom.equalTo(nameView);
        make.left.equalTo(nameView).offset(16);
        make.right.equalTo(nameView).offset(-10);
    }];
    [passView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(nameView.mas_bottom).offset(10);
        make.left.and.right.and.height.equalTo(nameView);
    }];
    [_passTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.bottom.equalTo(passView);
        make.left.equalTo(passView).offset(16);
        make.right.equalTo(findBtn.mas_left).offset(-5);
    }];
    
    [findBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(passView);
        make.right.equalTo(passView).offset(-5);
        make.size.mas_equalTo(CGSizeMake(80, 26));
    }];
    [_registerButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(nameView);
        make.top.equalTo(passView.mas_bottom).offset(30);
        make.height.mas_equalTo(44);
    }];
    
    [ownView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(142);
        make.right.equalTo(self.view).offset(-142);
        make.top.equalTo(_registerButton.mas_bottom).offset(20);
        make.height.mas_equalTo(20);
    }];
    
    [ownLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.top.and.height.equalTo(ownView);
    }];
    [ownBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.and.top.and.height.equalTo(ownView);
    }];
    
}

- (void)bindViewModel
{
    [super bindViewModel];
    @weakify(self);
    RAC(self.viewModel, userName) = self.nameTextField.rac_textSignal;
    RAC(self.viewModel, code) = self.passTextField.rac_textSignal;

    [self.viewModel.validCodeSignal subscribeNext:^(NSNumber *x) {
        @strongify(self);
        self.findBtn.enabled = x.boolValue;
    }];

    //获取验证码
    self.findBtn.rac_command = self.viewModel.getCodeCommand;
    //错误
    [[RACSignal
      merge:@[self.viewModel.getCodeCommand.errors]]
     subscribeNext:^(NSError *error) {
         [SVProgressHUD setMaximumDismissTimeInterval:1.5];
         [SVProgressHUD showErrorWithStatus:error.localizedDescription];
     }];
    //成功
    [[[self.viewModel.getCodeCommand executionSignals] switchToLatest] subscribeNext:^(id x) {
        @strongify(self)
        //自动换行
        [self.passTextField becomeFirstResponder];
    }];

    [[RACObserve(self.viewModel, countDownTime) filter:^BOOL(NSString *value) {
        return value.length > 0;
    }] subscribeNext:^(NSString *value) {
        @strongify(self);
        [self.findBtn setTitle:value forState:UIControlStateNormal];
    }];


    RAC(self.registerButton,enabled) = self.viewModel.registerSignal;

    [[[self.registerButton rac_signalForControlEvents:UIControlEventTouchUpInside] doNext:^(id x) {
        @strongify(self);
        self.registerButton.enabled = NO;
    }] subscribeNext:^(id x) {
        @strongify(self);
        RACSignal *signal = [self.viewModel.registerCommand execute:nil];
        [signal subscribeNext:^(id x) {
            //保存用户名跟密码
            [SVProgressHUD dismiss];
            //跳转页面
            ZYDoFinishViewController *vc = [[ZYDoFinishViewController alloc] init];
            vc.type = @"注册";
            [self.navigationController pushViewController:vc animated:YES];

        }];
    }];
    
}

#pragma mark -- 懒加载属性
- (MFRegisterViewModel *)viewModel
{
    if (!_viewModel) {
        _viewModel = [[MFRegisterViewModel alloc] init];
    }
    return _viewModel;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (YPNavigationBarConfigurations) yp_navigtionBarConfiguration {
    return YPNavigationBarStyleLight | YPNavigationBarBackgroundStyleTransparent | YPNavigationBarBackgroundStyleNone;
}

-(UIColor *)yp_navigationBarTintColor
{
    return [UIColor blackColor];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
