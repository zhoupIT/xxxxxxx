//
//  ZYDoFinishViewController.m
//  Zoo
//
//  Created by zhangyu on 2018/6/26.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "ZYDoFinishViewController.h"
#import "MFKitMarcro.h"
#import "MFKitBases.h"
#import "UIImage+MFAdd.h"
#import <Masonry/Masonry.h>
#import <BlocksKit/UIControl+BlocksKit.h>
@interface ZYDoFinishViewController ()

@property(nonatomic, strong) MFButton *goLoginBtn;

@end

@implementation ZYDoFinishViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if ([self.type isEqualToString:@"注册"]) {
        self.title = @"注册成功";
    }
}

- (void)configView{
    [super configView];
    self.view.backgroundColor = [MFColor whiteColor];
    //logo
    MFImageView *logoBgView = [[MFImageView alloc] init];
    logoBgView.image = [UIImage imageNamed:@"logoBgImage" bundleClass:[self class]];
    [self.view addSubview:logoBgView];
    MFImageView *logoImageView = [[MFImageView alloc] init];
//    logoImageView.image = [UIImage imageNamed:@"logo" bundleClass:[self class]];
    [logoBgView addSubview:logoImageView];
    
    _goLoginBtn = [MFButton buttonWithType:UIButtonTypeCustom];
    [_goLoginBtn setBackgroundImage:[UIImage imageNamed:@"loginBtnImage"] forState:UIControlStateNormal];
    _goLoginBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
    [_goLoginBtn setTitle:@"去登录" forState:UIControlStateNormal];
    [self.view addSubview:_goLoginBtn];
    [_goLoginBtn bk_addEventHandler:^(id sender) {
        NSLog(@"返回");
        int index = (int)[[self.navigationController viewControllers] indexOfObject:self];
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:(index -2)] animated:YES];
        
    } forControlEvents:UIControlEventTouchUpInside];
    
    [logoBgView mas_makeConstraints:^(MASConstraintMaker *make) {
//        @strongify(self);
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.view).offset(kNavigationHeight + 82);
        make.width.and.height.mas_equalTo(70);
    }];
    [logoImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.and.centerY.equalTo(logoBgView);
    }];
    
    [_goLoginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(45);
        make.right.equalTo(self.view).offset(-45);
        make.top.equalTo(logoBgView.mas_bottom).offset(59);
        make.height.mas_equalTo(44);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
