//
//  ZYDoFinishViewController.h
//  Zoo
//
//  Created by zhangyu on 2018/6/26.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFViewController.h"

@interface ZYDoFinishViewController : MFViewController

@property (nonatomic, copy) NSString *type;

@end
