//
//  MFRegisterViewModel.m
//  Zoo
//
//  Created by tanfameng on 2018/2/28.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFRegisterViewModel.h"
#import <ReactiveCocoa/ReactiveCocoa.h>
#import "MFNetRequestBusiness.h"
#import "NSDate+MFAdd.h"
#import "NSString+MFAdd.h"

#import "MFAccountManager.h"
#import "MFAccount.h"

#define RETRY_WAITING_TIME 60

@interface MFRegisterViewModel()

@property (nonatomic, strong, readwrite) RACSignal *registerSignal;

@property (nonatomic, strong, readwrite) RACSignal *validCodeSignal;

@property (nonatomic, strong, readwrite) RACCommand *registerCommand;

@property (nonatomic, strong, readwrite) RACCommand *getCodeCommand;

@property(nonatomic, assign) NSInteger validateCodeRetryTime;

@property(nonatomic, strong) NSTimer *timer;

@end

@implementation MFRegisterViewModel


- (instancetype)init
{
    self = [super init];
    if (self) {
        self.countDownTime = @"获 取";
    }
    return self;
}

-(void)dealloc
{
    if (_timer && _timer.isValid) {
        [_timer invalidate];
    }
    _timer = nil;
}

#pragma mark -- override Method
- (void)bindModel
{
    [super bindModel];
    
    //获取验证码按钮是否有效
    self.validCodeSignal = [[[RACObserve(self, userName) takeUntil:[self rac_willDeallocSignal]] map:^id(NSString *value) {
        return @([value verifyPhoneNumber]);
    }] distinctUntilChanged];
    
    //提交按钮是否有效，合并两项检测，要获取验证码按钮有效，且输入了验证码，提交按钮才有效
    self.registerSignal = [[RACSignal
                              combineLatest:@[RACObserve(self, userName), RACObserve(self, code)]
                              reduce:^(NSString *username, NSString *code) {
                                  return @(username.length > 0 && code.length > 0);
                              }]
                             distinctUntilChanged];
    
    @weakify(self);
    self.registerCommand = [[RACCommand alloc] initWithEnabled:nil signalBlock:^RACSignal *(id input) {
        
        RACSignal *regSignal = [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
            @strongify(self)
            //注册
            NSURLSessionTask *task = [self registerSuccess:^(BOOL succsee) {
//                [subscriber sendNext:token];
                [subscriber sendCompleted];
            } failure:^(NSError *error) {
                [subscriber sendError:error];
            }];
            
            return [RACDisposable disposableWithBlock:^{
                //该block中做一些清理工作，比如取消网络请求，或者取消数据库请求
                [task cancel];
            }];
        }];
        return regSignal;
    }];
}


#pragma mark -- 懒加载属性

- (RACCommand *)getCodeCommand
{
    if (_getCodeCommand) {
        return _getCodeCommand;
    }
    
    RACSignal *retrySignal = [[RACObserve(self, validateCodeRetryTime) takeUntil:[self rac_willDeallocSignal]] map:^id(NSNumber *value) {
        return @([value integerValue] == 0);
    }];
    
    RACSignal *enabledSignal = [RACSignal combineLatest:@[[self validCodeSignal],retrySignal] reduce:^id(NSNumber *phoneNumber,NSNumber *codeRetry){
        return @([phoneNumber boolValue] && [codeRetry boolValue]);
    }];
    
    @weakify(self);
    _getCodeCommand = [[RACCommand alloc] initWithEnabled:enabledSignal signalBlock:^RACSignal *(id input) {
        return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
            @strongify(self);
            //开始获取
            self.countDownTime = @"正在获取...";
            
            //请求获取
            NSURLSessionTask *task = [self getRegisterCodeSuccess:^(BOOL success) {
                [self startCodeRetryWaiting];
//                [subscriber sendNext:token];
                [subscriber sendCompleted];
            } failure:^(NSError *error) {
                self.countDownTime = @"获 取";
                self.validateCodeRetryTime = 0;
                [subscriber sendError:error];
            }];
            return [RACDisposable disposableWithBlock:^{
                //该block中做一些清理工作，比如取消网络请求，或者取消数据库请求
            }];
        }];
    }];
    return _getCodeCommand;
}

#pragma mark -- 业务方法
//获取验证码
- (NSURLSessionTask *)getRegisterCodeSuccess:(void (^)(BOOL success))completion failure:(void (^)(NSError *error))failure
{
    MFNetRequestBusiness *business = [MFNetRequestBusiness shareInstance];
    return [business getRegisterCodeWithMobile:self.userName success:^(NSString *code) {
        if (completion) {
            completion(code);
        }
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
    }];
}

//注册
- (NSURLSessionTask *)registerSuccess:(void (^)(BOOL success))completion failure:(void (^)(NSError *error))failure
{
    MFNetRequestBusiness *business = [MFNetRequestBusiness shareInstance];
    return [business registerWithUserName:self.userName passWord:self.code success:^(id response) {
        if (completion) {
            completion(YES);
        }
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
    }];
}


#pragma mark -- private
-(void) startCodeRetryWaiting
{
    self.validateCodeRetryTime = RETRY_WAITING_TIME;
    self.countDownTime = [NSString stringWithFormat:@"%zds",self.validateCodeRetryTime];
    
    if (_timer && _timer.isValid) {
        [_timer invalidate];
    }
    
    NSDate *beginDate = [NSDate date];
    _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerSelector:) userInfo:@{@"beginDate":beginDate} repeats:YES];
}

-(void) timerSelector:(NSTimer *) timer
{
    NSDate *beginDate = [[timer userInfo] objectForKey:@"beginDate"];
    NSDate *date = [NSDate date];
    NSTimeInterval time = [date timeIntervalSinceDate:beginDate];
    if (time >= RETRY_WAITING_TIME) {
        [self.timer invalidate];
        self.validateCodeRetryTime = 0;
        self.countDownTime = @"获 取";
    }else{
        self.countDownTime = [NSString stringWithFormat:@"%.0fs",RETRY_WAITING_TIME - time];
    }
}

#pragma mark -- 返回数据处理
- (void)dealData:(NSArray *)data
{
    
}

@end
