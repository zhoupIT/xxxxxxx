//
//  CTAuthenTemplate.m
//  CTYun
//
//  Created by tanfameng on 2018/3/7.
//  Copyright © 2018年 CTYun. All rights reserved.
//

#import "CTAuthenTemplate.h"
#import <YYModel/YYModel.h>

@implementation CTAuthenTemplate

- (instancetype)init
{
    self = [super init];
    if (self) {
        _structures = [[NSMutableArray alloc] init];
    }
    return self;
}

@end
