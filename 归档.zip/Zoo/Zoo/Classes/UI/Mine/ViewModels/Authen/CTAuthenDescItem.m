//
//  CTAuthenDescItem.m
//  CTYun
//
//  Created by tanfameng on 2018/3/3.
//  Copyright © 2018年 CTYun. All rights reserved.
//

#import "CTAuthenDescItem.h"

@implementation CTAuthenDescItem

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (CGFloat)cellHeight
{
    return UITableViewAutomaticDimension;
}

@end
