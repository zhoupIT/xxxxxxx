//
//  CTAuthenButtonItem.m
//  CTYun
//
//  Created by tanfameng on 2018/3/3.
//  Copyright © 2018年 CTYun. All rights reserved.
//

#import "CTAuthenButtonItem.h"

@implementation CTAuthenButtonItem

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (CGFloat)cellHeight
{
    return UITableViewAutomaticDimension;
}

@end
