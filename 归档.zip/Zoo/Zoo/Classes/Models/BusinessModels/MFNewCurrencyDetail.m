//
//  MFNewCurrencyDetail.m
//  Zoo
//
//  Created by tanfameng on 2018/2/27.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFNewCurrencyDetail.h"

@implementation MFNewCurrencyDetail

- (instancetype)init
{
    self = [super init];
    if (self) {
        _baseInfos = [[NSMutableArray alloc] init];
    }
    return self;
}

@end
