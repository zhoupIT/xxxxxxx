//
//  MFTimeLineInfo.m
//  Zoo
//
//  Created by tanfameng on 2018/2/11.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFTimeLineInfo.h"

@implementation MFTimeLineInfo

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

@end
