//
//  MFAccountInfo.m
//  Zoo
//
//  Created by tanfameng on 2018/3/4.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFAccountInfo.h"

@implementation MFAccountInfo

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

@end
