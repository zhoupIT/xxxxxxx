//
//  MFComment.m
//  Zoo
//
//  Created by tanfameng on 2018/6/4.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFComment.h"

@implementation MFComment

- (BOOL)isEqual:(MFComment *)object
{
    if ([self.commentId isEqual:object.commentId]) {
        return YES;
    }
    return NO;
}

@end
