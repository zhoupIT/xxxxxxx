//
//  MFComment.h
//  Zoo
//
//  Created by tanfameng on 2018/6/4.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFObject.h"

@interface MFComment : MFObject

@property (nonatomic, strong) NSString *commentId;

@property (nonatomic, strong) NSString *icon;

@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) NSString *time;

@property (nonatomic, strong) NSString *comment;

- (BOOL)isEqual:(MFComment *)object;

@end
