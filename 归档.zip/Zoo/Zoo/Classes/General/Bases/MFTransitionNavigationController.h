//
//  MFTransitionNavigationController.h
//  Zoo
//
//  Created by tanfameng on 2018/3/3.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFNavigationController.h"

@interface MFTransitionNavigationController : MFNavigationController

@end
