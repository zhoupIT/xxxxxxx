//
//  MFCommentFormatter.m
//  Zoo
//
//  Created by tanfameng on 2018/6/4.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFCommentFormatter.h"
#import "NSDate+MFAdd.h"
#import "MFComment.h"

@implementation MFCommentFormatter

- (id)convertModelFromJsonObject:(id)jsonObject
{
    NSDictionary *data = [jsonObject objectForKey:@"comments"];
    NSArray *comments = [data objectForKey:@"data"];
    
    NSMutableArray *commentLsit = [[NSMutableArray alloc] init];
    
    for (NSDictionary *commentDic in comments) {
        MFComment *comment = [[MFComment alloc] init];
        NSString *commentId = [commentDic objectForKey:@"id"];
        comment.commentId = commentId;
        NSString *content = [commentDic objectForKey:@"content"];
        comment.comment = content;
        if (![self checkNullOrNilValue:[commentDic objectForKey:@"icon_url"]]) {
            NSString *icon = [commentDic objectForKey:@"icon_url"];
            comment.icon = icon;
        }
        NSString *publish = [commentDic objectForKey:@"updated_at"];
        NSDate *date = [NSDate dateWithString:publish format:@"yyyy-MM-dd HH:mm:ss"];
        comment.time = [date stringWithFormat:@"yyyy-MM-dd"];
        NSDictionary *userDic = [commentDic objectForKey:@"user"];
        NSString *mobile = [userDic objectForKey:@"mobile"];
        comment.name = mobile;
        
        [commentLsit addObject:comment];
    }
    
    return commentLsit;
}

@end
