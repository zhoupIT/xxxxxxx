//
//  MFLoginFormatter.h
//  Zoo
//
//  Created by tanfameng on 2018/3/4.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFBaseDataFormatter.h"

@interface MFLoginFormatter : MFBaseDataFormatter

@end
