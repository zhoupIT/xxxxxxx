//
//  MFCommentFormatter.h
//  Zoo
//
//  Created by tanfameng on 2018/6/4.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFBaseDataFormatter.h"

@interface MFCommentFormatter : MFBaseDataFormatter

@end
