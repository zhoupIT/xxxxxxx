//
//  MFCurrencyClassFormatter.h
//  Zoo
//
//  Created by tanfameng on 2018/3/15.
//  Copyright © 2018年 tanfameng. All rights reserved.
//

#import "MFBaseDataFormatter.h"

@interface MFCurrencyClassFormatter : MFBaseDataFormatter

@end
