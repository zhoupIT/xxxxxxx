//
//  MFDBTranscation.m
//  Pods
//
//  Created by tanfameng on 2017/6/23.
//
//

#import "MFDBTranscation.h"
#import "MFDBManager.h"
#import <FMDB/FMDB.h>

@implementation MFDBTranscation
{
    
}

- (instancetype)init
{
    self = [super init];
    if (self) {

    }
    return self;
}

- (BOOL)begin
{
    return NO;
}

- (BOOL)commit
{
    return NO;
}

- (BOOL)rollback
{
    return NO;
}

@end
