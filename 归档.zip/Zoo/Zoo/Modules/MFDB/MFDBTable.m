//
//  MFBaseTable.m
//  Pods
//
//  Created by tanfameng on 2017/6/14.
//
//

#import "MFDBTable.h"
#import "MFDBManager.h"

@implementation MFDBTable

- (int)tableVersion
{
    return 1;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (BOOL)updateVersion:(int)oldVersion
{
    return YES;
}


@end
